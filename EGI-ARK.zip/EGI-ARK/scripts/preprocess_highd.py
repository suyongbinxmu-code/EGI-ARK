import argparse
from pathlib import Path
from egi_ark.highd import available_recordings, convert_recording


def main():
    p = argparse.ArgumentParser(description="Convert authorized highD CSV data to 10 Hz.")
    p.add_argument("--raw-dir", type=Path, default=Path("data/highd/raw"))
    p.add_argument("--out-dir", type=Path, default=Path("data/highd/processed"))
    p.add_argument("--recordings", nargs="*", default=None,
                   help="Optional IDs, e.g. 01 02 03; default: every available recording")
    p.add_argument("--overwrite", action="store_true", help="Replace converted files")
    a = p.parse_args()
    names = ([f"{int(x):02d}" for x in a.recordings]
             if a.recordings else available_recordings(a.raw_dir))
    if not names:
        p.error(f"No XX_tracks.csv found under {a.raw_dir}. See README for official download.")
    for rid in names:
        convert_recording(a.raw_dir, a.out_dir, rid, overwrite=a.overwrite)
    print(f"Converted {len(names)} highD recording(s) into {a.out_dir}.")


if __name__ == "__main__":
    main()
