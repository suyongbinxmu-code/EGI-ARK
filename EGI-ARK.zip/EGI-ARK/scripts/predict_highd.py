import argparse
import json
from pathlib import Path

import numpy as np

from egi_ark import Config, EGIARKV2
from egi_ark.highd import load_processed_scene


def _save_plot(out: Path, obs: np.ndarray, ids: list[int],
               particles: np.ndarray, edges: np.ndarray, n_plot: int = 4):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 5.5))
    lanes = edges[:, 0]
    for y in lanes[3:-3]:
        ax.axhline(y, color="0.8", linewidth=0.8, linestyle="--", zorder=0)
    colors = plt.get_cmap("tab10")
    shown = min(n_plot, len(ids))
    for a in range(shown):
        col = colors(a % 10)
        ax.plot(obs[:, a, 1], obs[:, a, 0], color=col, linewidth=1.5,
                label=f"Vehicle {ids[a]} (observed)")
        mu = particles[:, a].mean(axis=-1)
        ax.plot(mu[:, 1], mu[:, 0], color=col, linewidth=2.2,
                linestyle="--", label=f"Vehicle {ids[a]} (predicted mean)")
        for s in range(0, particles.shape[-1], max(1, particles.shape[-1] // 15)):
            ax.plot(particles[:, a, 1, s], particles[:, a, 0, s],
                    color=col, linewidth=0.5, alpha=0.12)
    ax.set_xlabel("Longitudinal position along travel direction (m)")
    ax.set_ylabel("Lateral position (m)")
    ax.set_title("EGI-ARK: observed histories and stochastic future samples")
    ax.grid(alpha=0.15)
    ax.legend(loc="best", fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(out / "prediction.png", dpi=200)
    fig.savefig(out / "prediction.pdf")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description="Run EGI-ARK predictions from converted highD observations.")
    parser.add_argument("--processed", type=Path,
                        default=Path("data/highd/processed/01_tracks1.csv"),
                        help="Converted direction-specific highD CSV")
    parser.add_argument("--start-frame", type=int, default=None,
                        help="10-Hz start frame; omit to choose the first eligible 30-frame history")
    parser.add_argument("--config", type=Path, default=Path("configs/default.json"))
    parser.add_argument("--n-samples", type=int, default=100,
                        help="Samples per nominal mode; output contains 3*n-samples")
    parser.add_argument("--seed", type=int, default=33)
    parser.add_argument("--out-dir", type=Path, default=Path("outputs/highd_example"))
    parser.add_argument("--no-plot", action="store_true")
    args = parser.parse_args()

    cfg = Config.load(args.config)
    if not np.isclose(cfg.dt, 0.1):
        parser.error("10-Hz highD input needs config.dt=0.1")
    if args.n_samples < 1:
        parser.error("--n-samples must be positive")

    obs, agent_ids, lane_edges, meta, start = load_processed_scene(args.processed, args.start_frame)
    particles, weights, result = EGIARKV2(cfg).predict_all(
        obs, lane_edges, n_samples=args.n_samples, n_steps=50, seed=args.seed
    )

    args.out_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.out_dir / "predictions.npz",
                        history=obs, agent_ids=np.array(agent_ids),
                        lane_edges=lane_edges, particles=particles, weights=weights,
                        mean_trajectory=particles.mean(axis=-1))
    diagnostic = []
    for agent, info in zip(agent_ids, result["diagnostics"]):
        diagnostic.append({
            "agent_id": int(agent),
            "target_lane_candidates": np.asarray(info["lanes"]).astype(int).tolist(),
            "target_lane_probabilities": np.asarray(info["lane_prob"]).tolist(),
            "residual_gate": float(info["residual_gate"]),
            "free_motion_posterior": float(info["free_motion_posterior"]),
            "effective_residual_scale_m_per_s2": float(info["effective_residual_scale"]),
        })
    summary = {
        "input": str(args.processed), "config": str(args.config),
        "recording_id": meta["recording_id"], "driving_direction": meta["driving_direction"],
        "history_start_frame_10hz": start, "history_end_frame_10hz": start+len(obs)-1,
        "model_dt_s": cfg.dt, "predicted_future_frames": int(len(particles)),
        "vehicle_ids": agent_ids, "particle_count_per_vehicle": int(particles.shape[-1]),
        "runtime_seconds": result["duration"], "seed": args.seed,
        "diagnostics": diagnostic,
    }
    (args.out_dir / "prediction_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8")
    if not args.no_plot:
        _save_plot(args.out_dir, obs, agent_ids, particles, lane_edges)
    print(f"Saved predictions to {args.out_dir.resolve()}")


if __name__ == "__main__":
    main()
