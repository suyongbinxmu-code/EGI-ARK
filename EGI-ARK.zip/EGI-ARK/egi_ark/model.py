from __future__ import annotations
from dataclasses import asdict, dataclass
from pathlib import Path
from time import perf_counter
from typing import Any
import json
import numpy as np

VERSION = "2.0.0"


@dataclass(frozen=True)
class Config:
    dt: float = 0.1
    sigma_obs: float = 0.03
    sigma_dv_lon: float = 0.05
    sigma_dv_lat: float = 0.05
    residual_scales: tuple[float, ...] = (0.0, 0.12, 0.30)
    residual_tau: float = 1.2
    k_control: int = 100
    k_grid: tuple[int, ...] = tuple(range(0, 121, 5))
    sigma_lane_target: float = 1.5
    sigma_desired_gap: float = 2.0
    sigma_desired_speed: float = 2.0
    forward_range: float = 50.0
    rear_range: float = 10.0
    warmup_points: int = 5
    interactions: bool = True

    zero_residual_prior: float = 0.82
    accel_gate_threshold: float = 0.30
    accel_gate_width: float = 0.65
    use_residual_gate: bool = True
    free_motion_prior: float = 0.65
    leader_distance_scale: float = 35.0
    use_interaction_gate: bool = True
    lane_prior_strength: float = 0.35
    use_lane_prior: bool = True

    def __post_init__(self):
        positive = (self.dt, self.sigma_obs, self.sigma_dv_lon,
                    self.sigma_dv_lat, self.residual_tau, self.sigma_lane_target,
                    self.sigma_desired_gap, self.sigma_desired_speed)
        if not all(np.isfinite(v) and v > 0 for v in positive):
            raise ValueError("Time constants and standard deviations must be finite and positive.")
        if not self.residual_scales or any(v < 0 or not np.isfinite(v) for v in self.residual_scales):
            raise ValueError("residual_scales must be a nonempty list of nonnegative SDs.")
        if self.k_control < 3 or not self.k_grid or any(k < 0 for k in self.k_grid):
            raise ValueError("Invalid control horizon / lane-change duration grid.")
        if self.warmup_points < 2:
            raise ValueError("warmup_points must be at least two.")
        for key in ("zero_residual_prior", "free_motion_prior", "lane_prior_strength"):
            value = getattr(self, key)
            if not np.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f"{key} must lie in [0,1].")
        if (self.accel_gate_threshold < 0 or self.accel_gate_width <= 0 or
                self.leader_distance_scale <= 0 or not np.isfinite(
                [self.accel_gate_threshold, self.accel_gate_width,
                 self.leader_distance_scale]).all()):
            raise ValueError("Acceleration and distance gate parameters must be finite and valid.")

    @classmethod
    def from_dict(cls, data: dict) -> "Config":
        data = dict(data)
        for key in ("residual_scales", "k_grid"):
            if key in data:
                data[key] = tuple(data[key])
        return cls(**data)

    @classmethod
    def load(cls, path: str | Path) -> "Config":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(data.get("config", data))

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")


def lane_index(lat: np.ndarray | float, lane_edges: np.ndarray) -> np.ndarray:

    return np.searchsorted(lane_edges[:, 0], lat, side="left") - 1


def controller_gains(k: np.ndarray | float) -> np.ndarray:


    k = np.asarray(k, dtype=float)
    aa = k * (k - 1.0) * (2.0*k - 1.0) / 6.0
    ab = k * (k - 1.0) / 2.0
    det = aa*k - ab*ab
    if np.any(k < 3) or np.any(det <= 0):
        raise ValueError("controller_gains requires horizons >= 3.")
    return np.stack(((k*(k-1)-ab)/det, (aa-(k-1)*ab)/det), axis=-1)


def _logsumexp(x: np.ndarray, axis: int | None = None) -> np.ndarray:
    m = np.max(x, axis=axis, keepdims=True)
    z = m + np.log(np.sum(np.exp(x-m), axis=axis, keepdims=True))
    return np.squeeze(z, axis=axis) if axis is not None else z.reshape(())


def _prob(logw: np.ndarray) -> np.ndarray:
    p = np.exp(logw - _logsumexp(logw))
    return p / p.sum()


def _update(x: np.ndarray, P: np.ndarray, y: float, r: float):

    if not np.isfinite(y):
        return x, P, np.zeros(x.shape[0])
    e = y - x[:, 0]
    s = np.maximum(P[:, 0, 0] + r, 1e-14)
    gain = P[:, :, 0] / s[:, None]
    x = x + gain * e[:, None]
    J = np.broadcast_to(np.eye(x.shape[-1]), P.shape).copy()
    J[:, :, 0] -= gain
    P = J @ P @ J.transpose(0, 2, 1) + r*gain[:, :, None]*gain[:, None, :]
    P = 0.5 * (P + P.transpose(0, 2, 1))
    loglik = -0.5 * (np.log(2*np.pi*s) + e*e/s)
    return x, P, loglik


def _initial_state(y: np.ndarray, cfg: Config):
    good = np.flatnonzero(np.isfinite(y))
    if len(good) < 4:
        raise ValueError("Each agent needs at least four finite history observations.")
    n0 = min(cfg.warmup_points, max(2, len(good)//3))
    use = good[:n0]
    end = int(use[-1])
    t = (use - end) * cfg.dt
    X = np.column_stack((np.ones(n0), t))
    beta = np.linalg.lstsq(X, y[use], rcond=None)[0]
    residual_var = max(cfg.sigma_obs**2, float(np.mean((y[use]-X@beta)**2)))
    cov = residual_var * np.linalg.pinv(X.T@X)
    cov += np.diag((1e-10, 0.05**2))
    return beta, cov, end


def _surround_states(p: np.ndarray, cfg: Config) -> np.ndarray:


    T, N = p.shape
    out = np.empty((T, N, 2))
    A = np.array([[1., cfg.dt], [0., 1.]])
    Q = np.diag([0., max(cfg.sigma_dv_lon, 0.05)**2])
    for a in range(N):
        beta, cov, end = _initial_state(p[:, a], cfg)

        out[:end+1, a, 0] = beta[0] + (np.arange(end+1)-end)*cfg.dt*beta[1]
        out[:end+1, a, 1] = beta[1]
        x, P = beta[None].copy(), cov[None].copy()
        for t in range(end+1, T):
            x = x @ A.T
            P = A @ P @ A.T + Q
            x, P, _ = _update(x, P, float(p[t, a]), cfg.sigma_obs**2)
            out[t, a] = x[0]
    return out


def _lateral_bank(y: np.ndarray, lanes: np.ndarray, edges: np.ndarray, cfg: Config):
    beta, cov, start = _initial_state(y, cfg)
    L, K = len(lanes), len(cfg.k_grid)
    count = L*K
    x = np.zeros((count, 3))
    x[:, :2] = beta
    x[:, 2] = np.repeat(edges[lanes, 1], K)
    P = np.zeros((count, 3, 3))
    P[:, :2, :2] = cov
    P[:, 2, 2] = cfg.sigma_lane_target**2
    k_initial = np.tile(cfg.k_grid, L)
    ll = np.zeros(count)
    hist = np.zeros((len(y), count))
    Q = np.diag((0., cfg.sigma_dv_lat**2, 0.))
    for t in range(start, len(y)-1):
        remaining = k_initial-t
        remaining = np.where(remaining >= 3, remaining, cfg.k_control)
        gains = controller_gains(remaining)
        A = np.broadcast_to(np.eye(3), (count, 3, 3)).copy()
        A[:, 0, 1] = cfg.dt
        A[:, 1, 0] = -gains[:, 0]/cfg.dt
        A[:, 1, 1] += -remaining*gains[:, 0]-gains[:, 1]
        A[:, 1, 2] = gains[:, 0]/cfg.dt
        x = np.einsum("bij,bj->bi", A, x)
        P = A @ P @ A.transpose(0, 2, 1) + Q
        x, P, d = _update(x, P, float(y[t+1]), cfg.sigma_obs**2)
        ll += d
        hist[t+1] = ll
    return dict(x=x, P=P, loglik=ll, history=hist,
                k=k_initial, lane=np.repeat(np.arange(L), K))


def _acceleration_gate(y: np.ndarray, cfg: Config):


    ids = np.flatnonzero(np.isfinite(y))[-24:]
    if len(ids) < 12:
        return 0.0, 0.0, 0.0
    chunks = np.array_split(ids, 3)
    if any(len(c) < 3 for c in chunks):
        return 0.0, 0.0, 0.0
    v = []
    times = []
    for c in chunks:
        times.append(float(c.mean()) * cfg.dt)
        t = (c - c.mean()) * cfg.dt
        X = np.column_stack((np.ones(len(c)), t))
        v.append(float(np.linalg.lstsq(X, y[c], rcond=None)[0][1]))
    a1 = (v[1] - v[0]) / max(times[1] - times[0], cfg.dt)
    a2 = (v[2] - v[1]) / max(times[2] - times[1], cfg.dt)
    a = 0.5 * (a1 + a2)
    consistency = 0.0 if a1*a2 <= 0 else min(abs(a1), abs(a2)) / max(abs(a1), abs(a2), 1e-8)
    gate = float(np.clip((abs(a)-cfg.accel_gate_threshold)/cfg.accel_gate_width, 0., 1.) *
                 (0.30 + 0.70*consistency))
    return gate, float(a), float(consistency)


def _residual_prior(cfg: Config, gate: float) -> np.ndarray:

    scales = np.asarray(cfg.residual_scales)
    m = len(scales)
    if m == 1:
        return np.ones(1)
    positive = scales > 0
    if not np.any(~positive):
        return np.full(m, 1/m)
    if not np.any(positive):
        return np.full(m, 1/m)
    base_nonzero = (1.-cfg.zero_residual_prior)
    mass_nonzero = base_nonzero * (gate if cfg.use_residual_gate else 1.)
    w = np.zeros(m)
    w[~positive] = (1.-mass_nonzero)/np.sum(~positive)
    w[positive] = mass_nonzero/np.sum(positive)

    return np.maximum(w, 1e-12) / np.maximum(w, 1e-12).sum()


def _lane_intent_prior(lat_obs: np.ndarray, lanes: np.ndarray, edges: np.ndarray,
                       cfg: Config) -> np.ndarray:

    L = len(lanes)
    uniform = np.full(L, 1./L)
    if not cfg.use_lane_prior or cfg.lane_prior_strength == 0.:
        return uniform
    ids = np.flatnonzero(np.isfinite(lat_obs))[-12:]
    if len(ids) < 4:
        return uniform
    t = (ids-ids[-1])*cfg.dt
    X = np.column_stack((np.ones(len(ids)), t))
    p0, vel = np.linalg.lstsq(X, lat_obs[ids], rcond=None)[0]

    projected_lat = float(p0 + np.clip(vel, -1.5, 1.5)*1.5)
    centres = edges[lanes, 1]

    logits = -0.5*((centres-projected_lat)/3.5)**2
    logits -= logits.max()
    soft = np.exp(logits)
    soft /= soft.sum()
    prior = (1.-cfg.lane_prior_strength)*uniform+cfg.lane_prior_strength*soft
    return prior/prior.sum()


def _leader_credibility(p: np.ndarray, ego: int, lead: int, lane: int,
                        edges: np.ndarray, cfg: Config) -> float:

    use = (np.isfinite(p[:, ego, 1]) & np.isfinite(p[:, lead, 1]) &
           np.isfinite(p[:, lead, 0]))
    ix = np.flatnonzero(use)[-15:]
    if not len(ix):
        return 0.01
    d = p[ix, lead, 1]-p[ix, ego, 1]
    same = lane_index(p[ix, lead, 0], edges) == lane
    ahead = d > 0.
    fraction = float(np.mean(same & ahead))
    forward_d = d[same & ahead]
    if not len(forward_d):
        return 0.01
    near = np.exp(-max(0., float(np.median(forward_d))-5.)/cfg.leader_distance_scale)
    return float(np.clip(fraction*near, 0.01, 1.))


def _leader_hypotheses(p: np.ndarray, ego: int, lane: int, current: int,
                       edges: np.ndarray, cfg: Config):

    if not cfg.interactions:
        return [(-1, 1.)]
    candidates = _candidate_leaders(p, ego, lane, current, edges, cfg)
    if not candidates:
        return [(-1, 1.)]
    if not cfg.use_interaction_gate:
        mass = 1. / len(candidates)
        return [(lead, mass) for lead in candidates]
    credibility = np.array([_leader_credibility(p, ego, a, lane, edges, cfg)
                            for a in candidates])
    maxq = float(credibility.max())

    mass_free = np.clip(cfg.free_motion_prior*(1.0-maxq), 0.1, 0.95)
    mass_follow = (1.-mass_free)*credibility / credibility.sum()
    return [(-1, float(mass_free))] + list(zip(candidates, mass_follow.tolist()))

def _candidate_leaders(p: np.ndarray, ego: int, lane: int, current: int,
                       edges: np.ndarray, cfg: Config) -> list[int]:
    if not cfg.interactions:
        return [-1]
    result = []
    for other in range(p.shape[1]):
        if other == ego:
            continue
        valid = np.isfinite(p[:, ego, 0]) & np.isfinite(p[:, other, 0])
        if not valid.any():
            continue
        same_lane_once = np.any(lane_index(p[valid, other, 0], edges) == lane)
        d = p[valid, other, 1]-p[valid, ego, 1]

        min_gap = 0.0 if lane == current else -cfg.rear_range
        if same_lane_once and np.any(d >= min_gap) and np.any(d <= cfg.forward_range):
            result.append(other)
    return result


def _longitudinal_bank(p: np.ndarray, ego: int, lanes: np.ndarray,
                       edges: np.ndarray, surrounds: np.ndarray, cfg: Config):
    y = p[:, ego, 1]
    beta, cov, start = _initial_state(y, cfg)
    first = np.flatnonzero(np.isfinite(p[:, ego, 0]))[0]
    current = int(lane_index(p[first, ego, 0], edges))
    gate, accel_est, accel_consistency = _acceleration_gate(y, cfg)
    regime_prior = _residual_prior(cfg, gate)
    descriptors = []
    for li, lane in enumerate(lanes):
        for lead, leader_weight in _leader_hypotheses(p, ego, int(lane), current, edges, cfg):
            for ri, scale in enumerate(cfg.residual_scales):
                descriptors.append((li, lead, ri, scale,
                                    np.log(max(leader_weight, 1e-12))+
                                    np.log(max(regime_prior[ri], 1e-12))))
    d = np.asarray(descriptors, dtype=float)
    li, lead, ri = (d[:, j].astype(int) for j in range(3))
    scale = d[:, 3]
    M = len(d)
    x = np.zeros((M, 5))
    x[:, :2] = beta
    x[:, 3] = beta[1]
    P = np.zeros((M, 5, 5))
    P[:, :2, :2] = cov
    P[:, 3, 3] = cov[1, 1]+cfg.sigma_desired_speed**2
    P[:, 1, 3] = P[:, 3, 1] = cov[1, 1]
    P[:, 0, 3] = P[:, 3, 0] = cov[0, 1]
    P[:, 2, 2] = cfg.sigma_desired_gap**2
    P[:, 4, 4] = scale**2
    follows = lead >= 0
    x[follows, 2] = surrounds[start, lead[follows], 0]-beta[0]

    P[follows, 2, 2] += cov[0, 0]
    P[follows, 0, 2] = P[follows, 2, 0] = -cov[0, 0]
    P[follows, 1, 2] = P[follows, 2, 1] = -cov[0, 1]
    P[follows, 3, 2] = P[follows, 2, 3] = -cov[0, 1]
    A = np.broadcast_to(np.eye(5), (M, 5, 5)).copy()
    A[:, 0, 1] = cfg.dt
    A[:, 1, 1] = 1.-1./cfg.k_control
    A[:, 1, 3] = 1./cfg.k_control
    gain = controller_gains(cfg.k_control)
    A[follows, 1, 0] = -gain[0]/cfg.dt
    A[follows, 1, 1] = 1.-gain[0]*cfg.k_control+gain[1]
    A[follows, 1, 2] = -gain[0]/cfg.dt
    A[follows, 1, 3] = -gain[1]
    A[:, 1, 4] = cfg.dt
    rho = np.exp(-cfg.dt/cfg.residual_tau)
    A[:, 4, 4] = rho
    Q = np.zeros_like(P)
    Q[:, 1, 1] = cfg.sigma_dv_lon**2
    Q[:, 4, 4] = scale**2*(1.-rho**2)
    ll = np.zeros(M)
    hist = np.zeros((len(y), M))
    for t in range(start, len(y)-1):
        f = np.zeros((M, 5))
        f[follows, 1] = (surrounds[t, lead[follows], 0]*gain[0]/cfg.dt +
                         surrounds[t, lead[follows], 1]*gain[0]*cfg.k_control)
        x = np.einsum("bij,bj->bi", A, x)+f
        P = A @ P @ A.transpose(0, 2, 1)+Q
        x, P, delta = _update(x, P, float(y[t+1]), cfg.sigma_obs**2)
        ll += delta
        hist[t+1] = ll

    logprior = d[:, 4]
    return dict(x=x, P=P, loglik=ll, history=hist, lane=li,
                leader=lead, regime=ri, scale=scale, A=A, Q=Q,
                logprior=logprior, accel_gate=gate, accel_est=accel_est,
                accel_consistency=accel_consistency, regime_prior=regime_prior)


def _draw_gaussian(x: np.ndarray, P: np.ndarray, rng: np.random.Generator):

    vals, vectors = np.linalg.eigh(0.5*(P+P.transpose(0, 2, 1)))
    if vals.min() < -1e-6:
        raise FloatingPointError(f"Posterior covariance is not PSD: {vals.min():.3g}")
    z = rng.standard_normal(x.shape) * np.sqrt(np.maximum(vals, 0.))
    return x + np.einsum("bij,bj->bi", vectors, z)


def _sample_indices(weights: np.ndarray, size: int, rng: np.random.Generator):

    if size == 0:
        return np.zeros(0, dtype=int)
    cdf = np.cumsum(weights)
    cdf[-1] = 1.0
    u = (np.arange(size)+rng.random(size))/size
    out = np.searchsorted(cdf, u)
    rng.shuffle(out)
    return out


def _single(p: np.ndarray, ego: int, edges: np.ndarray, surrounds: np.ndarray,
            cfg: Config, samples: int, steps: int, rng: np.random.Generator):
    first = np.flatnonzero(np.isfinite(p[:, ego, 0]))[0]
    current = int(lane_index(p[first, ego, 0], edges))
    lanes = np.array([current, current+1, current-1], dtype=int)
    lanes = lanes[(lanes >= 0) & (lanes < len(edges)-1)]
    lat = _lateral_bank(p[:, ego, 0], lanes, edges, cfg)
    lon = _longitudinal_bank(p, ego, lanes, edges, surrounds, cfg)
    T, L = len(p), len(lanes)
    K = len(cfg.k_grid)
    lane_prior = _lane_intent_prior(p[:, ego, 0], lanes, edges, cfg)
    lane_log = np.empty((T, L))
    for j in range(L):
        lane_log[:, j] = (
            _logsumexp(lat["history"][:, lat["lane"] == j], axis=1)-np.log(K) +
            _logsumexp(lon["history"][:, lon["lane"] == j] +
                       lon["logprior"][lon["lane"] == j], axis=1)+np.log(lane_prior[j]))
    lane_history = np.exp(lane_log-_logsumexp(lane_log, axis=1)[:, None])
    lane_samples = _sample_indices(lane_history[-1], samples, rng)
    lat_indices = np.empty(samples, dtype=int)
    lon_indices = np.empty(samples, dtype=int)
    regime_history = np.zeros((T, len(cfg.residual_scales)))
    final_lon_weights = np.zeros(len(lon["x"]))
    for j in range(L):
        aidx = np.flatnonzero(lat["lane"] == j)
        bidx = np.flatnonzero(lon["lane"] == j)
        use = np.flatnonzero(lane_samples == j)
        lat_indices[use] = aidx[_sample_indices(_prob(lat["loglik"][aidx]), len(use), rng)]
        bl = lon["loglik"][bidx]+lon["logprior"][bidx]
        final_lon_weights[bidx] = lane_history[-1, j]*_prob(bl)
        lon_indices[use] = bidx[_sample_indices(_prob(bl), len(use), rng)]
        hist = lon["history"][:, bidx]+lon["logprior"][bidx]
        bh = np.exp(hist-_logsumexp(hist, axis=1)[:, None])
        for r in range(len(cfg.residual_scales)):
            regime_history[:, r] += lane_history[:, j]*bh[:, lon["regime"][bidx] == r].sum(axis=1)
    assert np.array_equal(lat["lane"][lat_indices], lon["lane"][lon_indices])
    xl = _draw_gaussian(lat["x"][lat_indices], lat["P"][lat_indices], rng)
    xs = _draw_gaussian(lon["x"][lon_indices], lon["P"][lon_indices], rng)
    leaders = lon["leader"][lon_indices]
    follows = leaders >= 0
    lp = np.zeros(samples)
    lv = np.zeros(samples)
    lp[follows] = surrounds[-1, leaders[follows], 0]
    lv[follows] = surrounds[-1, leaders[follows], 1]
    gain = controller_gains(cfg.k_control)
    rho = np.exp(-cfg.dt/cfg.residual_tau)
    residual_innovation = lon["scale"][lon_indices]*np.sqrt(1.-rho**2)
    out = np.empty((steps, 2, samples))
    k_initial = lat["k"][lat_indices]
    for t in range(steps):
        remaining = k_initial-(T-1+t)
        remaining = np.where(remaining >= 3, remaining, cfg.k_control)
        g = controller_gains(remaining)
        dv_lat = g[:, 0]*((xl[:, 2]-xl[:, 0])/cfg.dt-remaining*xl[:, 1])-g[:, 1]*xl[:, 1]
        xl[:, 0] += cfg.dt*xl[:, 1]
        xl[:, 1] += dv_lat+cfg.sigma_dv_lat*rng.standard_normal(samples)

        xs[:, 1] = np.maximum(xs[:, 1], 0.)
        dv = (xs[:, 3]-xs[:, 1])/cfg.k_control
        dv[follows] = (
            gain[0]*((lp[follows]-xs[follows, 0]-xs[follows, 2])/cfg.dt +
                     cfg.k_control*(lv[follows]-xs[follows, 1])) +
            gain[1]*(xs[follows, 1]-xs[follows, 3]))
        xs[:, 0] += cfg.dt*xs[:, 1]
        xs[:, 1] = np.maximum(0., xs[:, 1]+dv+cfg.dt*xs[:, 4]+
                              cfg.sigma_dv_lon*rng.standard_normal(samples))
        xs[:, 4] = rho*xs[:, 4]+residual_innovation*rng.standard_normal(samples)
        lp += cfg.dt*lv
        lv += cfg.sigma_dv_lon*rng.standard_normal(samples)
        out[t, 0], out[t, 1] = xl[:, 0], xs[:, 0]
    final_regime = regime_history[-1]
    diagnostics = dict(
        lanes=lanes, lane_prob=lane_history[-1], lane_history=lane_history,
        regime_prob=final_regime, regime_history=regime_history,
        residual_scales=np.asarray(cfg.residual_scales),
        residual_gate=lon["accel_gate"],
        estimated_history_acceleration=lon["accel_est"],
        acceleration_consistency=lon["accel_consistency"],
        residual_regime_prior=lon["regime_prior"],
        lane_prior=lane_prior,
        free_motion_posterior=float(final_lon_weights[lon["leader"] == -1].sum()),
        posterior_residual_acceleration=float(final_lon_weights @ lon["x"][:, 4]),
        effective_residual_scale=float(np.sqrt(final_regime @ np.square(cfg.residual_scales))),
        sampled_lane=lanes[lane_samples], sampled_leader=leaders,
        sampled_regime=lon["regime"][lon_indices],
        lane_pairing_valid=True,
    )
    return out, diagnostics


class EGIARKV2:
    def __init__(self, config: Config | None = None):
        self.config = config or Config()

    def predict_all(self, p: np.ndarray, lane_edges: np.ndarray, n_samples: int = 100,
                    n_steps: int = 50, *, seed: int = 1,
                    return_diagnostics: bool = True):


        tic = perf_counter()
        p = np.asarray(p, dtype=float)
        edges = np.asarray(lane_edges, dtype=float)
        if p.ndim != 3 or p.shape[-1] != 2 or p.shape[0] < 4 or p.shape[1] == 0:
            raise ValueError("p must have shape (>=4, >=1, 2).")
        if np.isinf(p).any() or np.any(np.isfinite(p[..., 0]) != np.isfinite(p[..., 1])):
            raise ValueError("Both coordinates must be finite or both NaN.")
        if edges.ndim != 2 or edges.shape[1] != 2 or len(edges) < 2 or not np.isfinite(edges).all():
            raise ValueError("lane_edges must be finite (boundaries, 2).")
        if np.any(np.diff(edges[:, 0]) <= 0):
            raise ValueError("Lane boundaries must increase strictly.")
        if n_samples < 1 or n_steps < 1:
            raise ValueError("n_samples and n_steps must be positive.")
        valid_lat = p[..., 0][np.isfinite(p[..., 0])]
        if np.any(valid_lat <= edges[0, 0]) or np.any(valid_lat > edges[-1, 0]):
            raise ValueError("Observed positions lie outside provided lane boundaries.")
        rng = np.random.default_rng(seed)
        surroundings = _surround_states(p[..., 1], self.config)
        S = 3*int(n_samples)
        pred = np.empty((n_steps, p.shape[1], 2, S))
        details = []
        for a in range(p.shape[1]):
            pred[:, a], d = _single(p, a, edges, surroundings, self.config, S, n_steps, rng)
            if return_diagnostics:
                details.append(d)
        if not np.isfinite(pred).all():
            raise FloatingPointError("EGI-ARK v2 generated non-finite predictions.")
        info: dict[str, Any] = dict(duration=perf_counter()-tic, version=VERSION,
                                   config=asdict(self.config), diagnostics=details)
        return pred, np.full((p.shape[1], S), 1./S), info


def predict_all(p, lane_edges, n_samples=100, n_steps=50, *, config=None, seed=1):

    return EGIARKV2(config).predict_all(p, lane_edges, n_samples, n_steps, seed=seed)


def _self_test() -> dict:
    bounds = np.arange(-11.4, 26.7, 3.8)
    edges = np.column_stack((bounds, np.r_[(bounds[:-1]+bounds[1:])/2, 0.]))
    t = np.arange(30)*0.1
    p = np.empty((30, 3, 2))
    p[:, :, 0] = [1.9, 1.9, 5.7]
    p[:, 0, 1] = 25*t+0.25*t*t
    p[:, 1, 1] = 35+25*t
    p[:, 2, 1] = 10+27*t
    np.random.seed(987)
    state = np.random.get_state()
    model = EGIARKV2()
    y, w, info = model.predict_all(p, edges, 20, 50, seed=5)
    assert y.shape == (50, 3, 2, 60) and np.allclose(w.sum(axis=1), 1)
    state2 = np.random.get_state()
    assert state[0] == state2[0] and np.array_equal(state[1], state2[1]) and state[2:] == state2[2:]
    y2 = model.predict_all(p, edges, 20, 50, seed=5)[0]
    assert np.array_equal(y, y2)
    assert all(d["lane_pairing_valid"] for d in info["diagnostics"])
    assert all(0 <= d["residual_gate"] <= 1 for d in info["diagnostics"])
    assert all(np.isclose(d["lane_prior"].sum(), 1) for d in info["diagnostics"])
    assert all(np.isclose(d["residual_regime_prior"].sum(), 1) for d in info["diagnostics"])

    v = np.arange(30)*0.1
    gg, acc, _ = _acceleration_gate(10+25*v, Config())
    assert gg == 0.0 and abs(acc) < 1e-8
    assert _residual_prior(Config(), gg)[0] > 0.999
    hot_gate, hot_acc, _ = _acceleration_gate(10 + 25*v + 0.5*1.0*v*v, Config())
    assert hot_gate > 0.9 and abs(hot_acc-1.0) < 1e-8
    assert _residual_prior(Config(), hot_gate)[0] < 0.90
    leaders = _leader_hypotheses(p, 0, int(lane_index(p[0,0,0], edges)),
                                 int(lane_index(p[0,0,0], edges)), edges, Config())
    assert any(k == -1 for k, prob in leaders)
    assert any(k >= 0 for k, prob in leaders)
    assert abs(sum(prob for _, prob in leaders)-1.) < 1e-10
    assert all(np.allclose(d["regime_history"].sum(axis=1), 1) for d in info["diagnostics"])
    shifted = p + np.array([0., 1000.])
    ys = model.predict_all(shifted, edges, 20, 50, seed=5)[0]
    assert np.allclose(ys, y+np.array([0., 1000.])[None, None, :, None], atol=2e-5)
    missing = p.copy()
    missing[12:17, 0] = np.nan
    missing[-3:, 1] = np.nan
    ym = model.predict_all(missing, edges, 10, 15, seed=9)[0]
    assert np.isfinite(ym).all()
    return {"status": "passed", "shape": list(y.shape),
            "history_only_residual_gate": True, "soft_leader_and_lane_priors": True, "seed_repeatability": True,
            "global_rng_unchanged": True, "lane_pairing": True,
            "translation_equivariance": True, "missing_history": True,
            "real_data_performance_tested": False}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="EGI-ARK model self-test.")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--write-default-config")
    args = parser.parse_args()
    if args.write_default_config:
        Config().save(args.write_default_config)
    if args.self_test:
        print(json.dumps(_self_test(), indent=2))
    elif not args.write_default_config:
        parser.print_help()
