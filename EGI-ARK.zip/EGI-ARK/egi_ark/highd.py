from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

RAW_HZ = 25
OUTPUT_HZ = 10
LANE_WIDTH_M = 3.8
REQUIRED_TRACK_COLUMNS = {"frame", "id", "x", "y", "height"}
REQUIRED_STATIC_COLUMNS = {"id", "drivingDirection"}
REQUIRED_META_COLUMNS = {"locationId", "frameRate", "upperLaneMarkings", "lowerLaneMarkings"}


def make_lane_edges(boundaries: np.ndarray) -> np.ndarray:


    bounds = np.asarray(boundaries, dtype=float).reshape(-1)
    if (len(bounds) < 2 or not np.isfinite(bounds).all() or
            np.any(np.diff(bounds) <= 0)):
        raise ValueError("Lane markings must be >=2 finite, strictly increasing coordinates.")
    ext = np.r_[bounds[0] - np.arange(3, 0, -1)*LANE_WIDTH_M,
                bounds,
                bounds[-1] + np.arange(1, 4)*LANE_WIDTH_M]
    return np.column_stack([ext, np.r_[(ext[:-1] + ext[1:])/2, 0.]])


def parse_markings(value: Any) -> np.ndarray:
    if isinstance(value, str):
        values = value.split(";")
    else:
        values = list(value)
    return np.asarray([float(s) for s in values], dtype=float)


def _raw_meta(raw_dir: Path, recording: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    st_path = raw_dir / f"{recording}_tracksMeta.csv"
    rec_path = raw_dir / f"{recording}_recordingMeta.csv"
    if not st_path.is_file() or not rec_path.is_file():
        raise FileNotFoundError(
            f"Missing {st_path.name} or {rec_path.name}; obtain the full highD recording."
        )
    stat = pd.read_csv(st_path)
    meta = pd.read_csv(rec_path)
    if not REQUIRED_STATIC_COLUMNS.issubset(stat.columns):
        raise ValueError(f"{st_path.name}: expected columns {sorted(REQUIRED_STATIC_COLUMNS)}")
    if meta.empty or not REQUIRED_META_COLUMNS.issubset(meta.columns):
        raise ValueError(f"{rec_path.name}: missing required metadata fields")
    if int(meta.iloc[0]["frameRate"]) != RAW_HZ:
        raise ValueError(f"{rec_path.name}: expected raw 25 Hz highD data")
    return stat, meta


def _resample_one_vehicle(raw: pd.DataFrame, direction: int) -> pd.DataFrame:

    raw = raw.sort_values("frame")
    frames = raw["frame"].to_numpy(dtype=np.int64)
    if len(frames) < 2:
        return pd.DataFrame(columns=["frame_id", "agent_id", "x", "y"])
    if np.any(np.diff(frames) <= 0):
        raise ValueError("Vehicle has duplicate or unsorted raw frame IDs.")
    lateral = raw["y"].to_numpy(float) + 0.5 * raw["height"].to_numpy(float)
    longitudinal = (1 if direction == 2 else -1) * raw["x"].to_numpy(float)
    if not np.isfinite(lateral).all() or not np.isfinite(longitudinal).all():
        raise ValueError("Non-finite highD positions/vehicle dimensions.")
    vehicle_id = int(raw["id"].iloc[0])
    cuts = np.r_[0, np.flatnonzero(np.diff(frames) != 1) + 1, len(frames)]
    parts: list[pd.DataFrame] = []
    for begin, end in zip(cuts[:-1], cuts[1:]):
        if end - begin < 2:
            continue
        f = frames[begin:end]


        first = int(np.ceil(f[0] * OUTPUT_HZ / RAW_HZ - 1e-10))
        last = int(np.floor(f[-1] * OUTPUT_HZ / RAW_HZ + 1e-10))
        if first > last:
            continue
        grid10 = np.arange(first, last + 1, dtype=np.int64)
        source_frame = grid10.astype(float) * (RAW_HZ / OUTPUT_HZ)
        parts.append(pd.DataFrame({
            "frame_id": grid10,
            "agent_id": vehicle_id,
            "x": np.interp(source_frame, f, lateral[begin:end]),
            "y": np.interp(source_frame, f, longitudinal[begin:end]),
        }))
    if not parts:
        return pd.DataFrame(columns=["frame_id", "agent_id", "x", "y"])
    out = pd.concat(parts, ignore_index=True)
    if out.duplicated(["frame_id", "agent_id"]).any():
        raise RuntimeError("Resampled segments overlap at identical vehicle timestamps.")
    return out


def convert_recording(raw_dir: str | Path, out_dir: str | Path,
                      recording: str | int, *, overwrite: bool = False) -> list[Path]:


    raw_dir, out_dir = Path(raw_dir), Path(out_dir)
    rid = f"{int(recording):02d}"
    track_path = raw_dir / f"{rid}_tracks.csv"
    if not track_path.is_file():
        raise FileNotFoundError(f"Expected highD raw file: {track_path}")
    static, rec_meta = _raw_meta(raw_dir, rid)
    allowed = static[["id", "drivingDirection"]].copy()
    allowed["id"] = allowed["id"].astype(np.int64)
    raw = pd.read_csv(track_path, usecols=lambda c: c in REQUIRED_TRACK_COLUMNS)
    if not REQUIRED_TRACK_COLUMNS.issubset(raw.columns):
        raise ValueError(f"{track_path.name}: expected {sorted(REQUIRED_TRACK_COLUMNS)}")
    if raw.empty:
        raise ValueError(f"Empty highD track data: {track_path}")
    if not np.isfinite(raw.to_numpy(float)).all():
        raise ValueError(f"Non-finite raw highD values in {track_path.name}")
    if raw.duplicated(["frame", "id"]).any():
        raise ValueError(f"Duplicate raw frame-vehicle rows in {track_path.name}")
    raw["frame"] = raw["frame"].astype(np.int64)
    raw["id"] = raw["id"].astype(np.int64)
    by_dir = {1: set(allowed.loc[allowed.drivingDirection == 1, "id"]),
              2: set(allowed.loc[allowed.drivingDirection == 2, "id"])}
    out_dir.mkdir(parents=True, exist_ok=True)
    planned = [out_dir / f"{rid}_tracks{d}.csv" for d in (1, 2)]
    if not overwrite and any(p.exists() or p.with_suffix(".meta.json").exists() for p in planned):
        raise FileExistsError(f"Output for {rid} exists; use --overwrite intentionally.")
    written = []
    for direction in (1, 2):
        relevant = raw[raw["id"].isin(by_dir[direction])]
        parts = []
        for _, vehicle in relevant.groupby("id", sort=True):
            sample = _resample_one_vehicle(vehicle, direction)
            if not sample.empty:
                parts.append(sample)
        if not parts:
            continue
        df = pd.concat(parts, ignore_index=True)
        df = df.sort_values(["frame_id", "agent_id"], kind="mergesort")
        if df.duplicated(["frame_id", "agent_id"]).any():
            raise RuntimeError("Duplicate processed frame-vehicle keys")
        field = "upperLaneMarkings" if direction == 1 else "lowerLaneMarkings"
        markings = parse_markings(rec_meta.iloc[0][field])
        edges = make_lane_edges(markings)
        output = out_dir / f"{rid}_tracks{direction}.csv"
        meta_path = output.with_suffix(".meta.json")
        df.to_csv(output, index=False, float_format="%.10g")
        info = dict(
            recording_id=rid,
            driving_direction=direction,
            location_id=int(rec_meta.iloc[0]["locationId"]),
            raw_frequency_hz=RAW_HZ, processed_frequency_hz=OUTPUT_HZ,
            interval_s=1.0/OUTPUT_HZ,
            coordinate_order=["lateral", "longitudinal"],
            coordinate_units="metres",
            longitudinal_definition=("-raw_x" if direction == 1 else "+raw_x"),
            lateral_definition="raw_y + raw_height / 2",
            lane_boundaries_m=markings.tolist(),
            lane_edges_m=edges.tolist(),
            positions_file=output.name,
            n_vehicles=int(df.agent_id.nunique()),
            n_rows=int(len(df)),
            notes="Time-aligned interpolation only within contiguous raw frame segments. No gap bridging.",
        )
        meta_path.write_text(json.dumps(info, indent=2), encoding="utf-8")
        written.extend((output, meta_path))
    return written


def available_recordings(raw_dir: str | Path) -> list[str]:
    raw_dir = Path(raw_dir)
    return sorted(set(m.group(1) for p in raw_dir.glob("*_tracks.csv")
                      if (m := re.fullmatch(r"(\d{2})_tracks\.csv", p.name))))


def load_processed_scene(processed_path: str | Path,
                         start_frame: int | None,
                         history_frames: int = 30):


    p = Path(processed_path)
    meta_path = p.with_suffix(".meta.json")
    if not p.is_file() or not meta_path.is_file():
        raise FileNotFoundError(f"Expected processed pair {p.name} and {meta_path.name}")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    if int(meta["processed_frequency_hz"]) != OUTPUT_HZ:
        raise ValueError("EGI-ARK highD example expects 10-Hz processed trajectories.")
    edges = np.asarray(meta["lane_edges_m"], dtype=float)
    df = pd.read_csv(p, usecols=["frame_id", "agent_id", "x", "y"])
    if df.empty:
        raise ValueError("Converted highD trajectory file is empty.")
    if df.duplicated(["frame_id", "agent_id"]).any():
        raise ValueError("Duplicate processed frame-agent key")
    df["frame_id"] = df["frame_id"].astype(np.int64)
    df["agent_id"] = df["agent_id"].astype(np.int64)
    if start_frame is None:
        starts: list[int] = []
        for _, group in df.groupby("agent_id"):
            frames = np.sort(group.frame_id.to_numpy())
            cuts = np.r_[0, np.flatnonzero(np.diff(frames) != 1)+1, len(frames)]
            starts.extend(int(frames[a]) for a, b in zip(cuts[:-1], cuts[1:])
                          if b - a >= history_frames)
        if not starts:
            raise ValueError("No vehicle has the required contiguous history window.")
        start_frame = min(starts)
    required = np.arange(start_frame, start_frame + history_frames, dtype=np.int64)
    clip = df[(df.frame_id >= start_frame) &
              (df.frame_id < start_frame + history_frames)]
    seq = []
    ids = []
    for agent, group in clip.groupby("agent_id", sort=True):
        g = group.sort_values("frame_id")
        if np.array_equal(g.frame_id.to_numpy(), required):
            seq.append(g[["x", "y"]].to_numpy(dtype=float))
            ids.append(int(agent))
    if not seq:
        raise ValueError(f"No agent continuously observed in [{start_frame},{start_frame+history_frames-1}]")
    history = np.stack(seq, axis=1)
    if not np.isfinite(history).all():
        raise ValueError("History includes non-finite coordinates")
    if np.any(history[..., 0] <= edges[0, 0]) or np.any(history[..., 0] > edges[-1, 0]):
        raise ValueError("Converted lateral coordinates outside lane geometry.")
    return history, ids, edges, meta, int(start_frame)
