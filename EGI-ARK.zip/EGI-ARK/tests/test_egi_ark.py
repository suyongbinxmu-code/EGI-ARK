import unittest
import numpy as np

from egi_ark import Config, EGIARKV2
from egi_ark.model import _self_test


class TestEGIARK(unittest.TestCase):
    def test_built_in_properties(self):
        result = _self_test()
        self.assertEqual(result["status"], "passed")
        self.assertTrue(result["lane_pairing"])
        self.assertTrue(result["global_rng_unchanged"])

    def test_api_weights_and_seed(self):
        t = np.arange(30)*0.1
        p = np.empty((30, 1, 2))
        p[:, 0, 0] = 1.9
        p[:, 0, 1] = 30 + 20*t + 0.1*t*t
        bounds = np.arange(-11.4, 19.1, 3.8)
        edges = np.column_stack([bounds, np.r_[(bounds[:-1]+bounds[1:])/2, 0.]])
        model = EGIARKV2(Config())
        one, w, _ = model.predict_all(p, edges, 4, 10, seed=123)
        two, _, _ = model.predict_all(p, edges, 4, 10, seed=123)
        self.assertEqual(one.shape, (10, 1, 2, 12))
        np.testing.assert_array_equal(one, two)
        np.testing.assert_allclose(w.sum(axis=1), 1.)


if __name__ == "__main__":
    unittest.main()
