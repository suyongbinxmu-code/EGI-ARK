# EGI-ARK

EGI-ARK is a standalone probabilistic model for highway vehicle trajectory prediction.

## Install

Python 3.10+ is required. 

## Obtain highD data

Request authorized access to the **highD dataset** from its provider: https://levelxdata.com/highd-dataset/ . After approval, put the original CSV files in `data/highd/raw/`. For recording 01, the required files are:

```text
data/highd/raw/01_tracks.csv
data/highd/raw/01_tracksMeta.csv
data/highd/raw/01_recordingMeta.csv
```

## Preprocess and predict

The preprocessing tool converts highD from 25 Hz to 10 Hz and writes one CSV per driving direction:

```bash
python -m scripts.preprocess_highd --raw-dir data/highd/raw --out-dir data/highd/processed --recordings 01
```

To preprocess every available authorized recording, omit `--recordings 01`. Run inference on a converted direction-specific file:

```bash
python -m scripts.predict_highd --processed data/highd/processed/01_tracks1.csv --config configs/default.json --n-samples 100 --seed 33 --out-dir outputs/example_01
```

Predictions are saved to `outputs/example_01/` (`predictions.npz`, `prediction_summary.json`, and PNG/PDF plots). With 30 observed frames (3 s), the example predicts 50 future frames (5 s). `--n-samples 100` produces **300** particles per vehicle. Array shape: `(future_steps, vehicles, 2, particles)`; spatial coordinates use **[lateral, longitudinal]** in metres, with longitudinal increasing in the direction of travel.

Optional tests:

```bash
python -m unittest discover -s tests -v
```
