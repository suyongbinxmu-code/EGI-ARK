import argparse
from pathlib import Path

from egi_ark.evaluation import select_parameters


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--processed', type=Path, default=Path('data/highd/processed'))
    parser.add_argument('--fold', choices=('A', 'B'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--max-val', type=int, default=500)
    parser.add_argument('--stride', type=int, default=20)
    parser.add_argument('--seed', type=int, default=33)
    parser.add_argument('--tuning-seed', type=int, default=117)
    parser.add_argument('--n-samples', type=int, default=100)
    parser.add_argument('--es-pairs', type=int, default=128)
    parser.add_argument('--ade-weight', type=float, default=0.5)
    args = parser.parse_args()
    result = select_parameters(args.processed, args.out, args.fold, args.max_val,
                               args.stride, args.seed, args.tuning_seed,
                               args.n_samples, args.es_pairs, args.ade_weight)
    print(f'{args.fold}: {result["candidate"]}, objective={result["selection_value_m"]:.6f}; {args.out}/calibration.json')


if __name__ == '__main__':
    main()
