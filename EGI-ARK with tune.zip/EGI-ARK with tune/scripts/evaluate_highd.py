import argparse
from pathlib import Path

from egi_ark.evaluation import evaluate_parameters


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--processed', type=Path, default=Path('data/highd/processed'))
    parser.add_argument('--calibration', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--n-samples', type=int, default=None)
    parser.add_argument('--es-pairs', type=int, default=None)
    parser.add_argument('--limit', type=int, default=0)
    args = parser.parse_args()
    summary = evaluate_parameters(args.processed, args.calibration, args.out,
                                  args.seed, args.n_samples, args.es_pairs, args.limit)
    if summary is not None:
        print(f'{summary["scenes_finished"]}/{summary["scenes_in_manifest"]} scenes; E-ADE={summary["expected_ADE_all50_m"]:.4f} m; RMSE5={summary["distributional_RMSE_5s_m"]:.4f} m; ES={summary["energy_score_avg_1to5_m"]:.4f} m; {args.out}/summary.csv')


if __name__ == '__main__':
    main()
