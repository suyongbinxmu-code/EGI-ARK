from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, replace
from functools import lru_cache
from hashlib import sha256
from itertools import groupby, product
from pathlib import Path
from time import perf_counter
import csv
import json
import math
import sqlite3

import numpy as np
import pandas as pd

from .model import Config, EGIARKV2, VERSION

HISTORY = 30
FUTURE = 50
WINDOW = HISTORY + FUTURE
HORIZONS = (9, 19, 29, 39, 49)


def file_sha(path):
    digest = sha256()
    with Path(path).open('rb') as src:
        for chunk in iter(lambda: src.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def stable_seed(*parts):
    digest = sha256('|'.join(map(str, parts)).encode('utf-8')).digest()
    return int.from_bytes(digest[:8], 'little') % (2**32)


def write_json(path, value):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')


def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_csv(path, rows, names):
    with Path(path).open('w', newline='', encoding='utf-8') as dst:
        writer = csv.DictWriter(dst, fieldnames=names)
        writer.writeheader()
        writer.writerows(rows)


def read_csv(path):
    with Path(path).open(newline='', encoding='utf-8') as src:
        return list(csv.DictReader(src))


def discover_processed(root):
    root = Path(root)
    catalog = []
    for path in sorted(root.glob('[0-9][0-9]_tracks[12].csv')):
        meta_file = path.with_suffix('.meta.json')
        if not meta_file.is_file():
            raise FileNotFoundError(str(meta_file))
        meta = load_json(meta_file)
        location = int(meta['location_id'])
        if location not in range(1, 7):
            raise ValueError(f'Unsupported highD location in {meta_file}: {location}')
        if int(meta['processed_frequency_hz']) != 10:
            raise ValueError(f'Expected 10 Hz in {meta_file}')
        edges = np.asarray(meta['lane_edges_m'], dtype=float)
        if (edges.ndim != 2 or edges.shape[1] != 2 or
                len(edges) < 2 or not np.isfinite(edges).all() or
                np.any(np.diff(edges[:, 0]) <= 0)):
            raise ValueError(f'Invalid lane edges in {meta_file}')
        record_id = f'{int(meta["recording_id"]):02d}'
        direction = int(meta['driving_direction'])
        if path.name != f'{record_id}_tracks{direction}.csv':
            raise ValueError(f'Recording metadata does not match {path.name}')
        catalog.append({
            'file': path.name,
            'meta': meta_file.name,
            'recording': f'highd_{record_id}',
            'location': location,
            'direction': direction,
            'sha256': file_sha(path),
            'meta_sha256': file_sha(meta_file),
        })
    if not catalog:
        raise FileNotFoundError(f'No converted highD files in {root}')
    return catalog


def validate_catalog(root, catalog):
    root = Path(root)
    for item in catalog:
        if (file_sha(root/item['file']) != item['sha256'] or
                file_sha(root/item['meta']) != item['meta_sha256']):
            raise RuntimeError(f'Data changed after protocol creation: {item["file"]}')


@lru_cache(maxsize=2)
def load_record(path_string):
    path = Path(path_string)
    meta = load_json(path.with_suffix('.meta.json'))
    df = pd.read_csv(path, usecols=['frame_id', 'agent_id', 'x', 'y'])
    if df.empty or df.isna().any().any() or not np.isfinite(df.to_numpy(float)).all():
        raise ValueError(f'Invalid non-finite highD data: {path}')
    for key in ('frame_id', 'agent_id'):
        if not np.equal(df[key].to_numpy(), np.floor(df[key].to_numpy())).all():
            raise ValueError(f'Noninteger {key}: {path}')
        df[key] = df[key].astype(np.int64)
    if df.duplicated(['frame_id', 'agent_id']).any():
        raise ValueError(f'Duplicate frame/agent entries: {path}')
    tracks, intervals = {}, []
    for agent, part in df.groupby('agent_id', sort=True):
        sorted_part = part.sort_values('frame_id')
        times = sorted_part.frame_id.to_numpy(dtype=np.int64)
        positions = sorted_part[['x', 'y']].to_numpy(dtype=float)
        if np.any(np.diff(times) <= 0):
            raise ValueError(f'Invalid frame order: {path}')
        tracks[int(agent)] = (times, positions)
        cuts = np.r_[0, np.flatnonzero(np.diff(times) != 1) + 1, len(times)]
        for left, right in zip(cuts[:-1], cuts[1:]):
            if right-left >= WINDOW:
                intervals.append((int(times[left]), int(times[right-1]-WINDOW+2), int(agent)))
    return tracks, intervals, np.asarray(meta['lane_edges_m'], dtype=float), int(df.frame_id.min()), int(df.frame_id.max())


def eligible_origins(path, stride):
    tracks, intervals, _, low, high = load_record(str(Path(path).resolve()))
    if not intervals:
        return np.empty(0, dtype=np.int64)
    diff = np.zeros(high-low+2, dtype=np.int32)
    for begin, exclusive_end, _ in intervals:
        diff[begin-low] += 1
        diff[exclusive_end-low] -= 1
    origins = np.flatnonzero(np.cumsum(diff[:-1]) > 0) + low
    return origins[(origins-low) % stride == 0]


def iter_scenes(root, manifest):
    root = Path(root)
    ordered = sorted(manifest, key=lambda x: (x['file'], int(x['frame'])))
    for filename, group in groupby(ordered, key=lambda x: x['file']):
        tracks, intervals, edges, _, _ = load_record(str((root/filename).resolve()))
        events = []
        for begin, exclusive_end, agent in intervals:
            events.append((begin, 1, agent))
            events.append((exclusive_end, -1, agent))
        events.sort(key=lambda z: z[0])
        active, pointer = set(), 0
        for item in group:
            start = int(item['frame'])
            while pointer < len(events) and events[pointer][0] <= start:
                _, op, agent = events[pointer]
                if op == 1:
                    active.add(agent)
                else:
                    active.remove(agent)
                pointer += 1
            agents = sorted(active)
            if not agents:
                raise RuntimeError(f'No 80-frame agent at {filename}:{start}')
            target_times = np.arange(start, start+WINDOW, dtype=np.int64)
            positions = []
            for agent in agents:
                frames, xy = tracks[agent]
                index = int(np.searchsorted(frames, start))
                if not np.array_equal(frames[index:index+WINDOW], target_times):
                    raise RuntimeError(f'Temporal gap in scene {filename}:{start}:{agent}')
                positions.append(xy[index:index+WINDOW])
            path = np.stack(positions, axis=1)
            yield item, path[:HISTORY], path[HISTORY:], edges, agents


def build_manifests(processed, fold, max_val, stride, selection_seed):
    if fold not in ('A', 'B'):
        raise ValueError('fold must be A or B')
    if max_val < 1 or stride < 1:
        raise ValueError('Validation size and stride must be positive')
    catalog = discover_processed(processed)
    development = {1, 2, 3} if fold == 'A' else {4, 5, 6}
    testing = {4, 5, 6} if fold == 'A' else {1, 2, 3}
    val_candidates, test_rows = [], []
    seen_val, seen_test = set(), set()
    for item in catalog:
        location = item['location']
        if location not in development | testing:
            continue
        file = item['file']
        starts = eligible_origins(Path(processed)/file, stride)
        rows = [{'scene_key': f'{file}:{int(frame)}', 'file': file,
                 'frame': int(frame), 'recording': item['recording'],
                 'location': location} for frame in starts]
        if location in development:
            val_candidates.extend(rows)
            seen_val.add(item['recording'])
        else:
            test_rows.extend(rows)
            seen_test.add(item['recording'])
    if not val_candidates or not test_rows:
        raise ValueError('Both development and test locations require eligible 80-frame scenes')
    if seen_val & seen_test:
        raise RuntimeError('Validation and test recording identities overlap')
    val_indices = np.sort(np.random.default_rng(stable_seed(selection_seed, fold, 'validation')).choice(
        len(val_candidates), min(max_val, len(val_candidates)), replace=False))
    validation = [val_candidates[int(i)] for i in val_indices]
    return catalog, validation, test_rows


def create_protocol(processed, folder, fold, max_val, stride, selection_seed):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    protocol_file = folder/'protocol.json'
    if protocol_file.exists():
        raise FileExistsError(f'Protocol already exists: {protocol_file}')
    catalog, val, test = build_manifests(processed, fold, max_val, stride, selection_seed)
    fields = ['scene_key', 'file', 'frame', 'recording', 'location']
    write_csv(folder/'validation_manifest.csv', val, fields)
    write_csv(folder/'test_manifest.csv', test, fields)
    write_json(folder/'catalog.json', catalog)
    specification = {
        'fold': fold, 'max_val': max_val, 'stride': stride,
        'manifest_seed': selection_seed, 'history_frames': HISTORY,
        'future_frames': FUTURE, 'time_step_s': 0.1,
        'validation_scenes': len(val), 'test_scenes': len(test),
        'catalog_sha256': file_sha(folder/'catalog.json'),
        'validation_sha256': file_sha(folder/'validation_manifest.csv'),
        'test_sha256': file_sha(folder/'test_manifest.csv'),
        'model_version': VERSION,
        'model_sha256': file_sha(Path(__file__).with_name('model.py')),
        'evaluation_sha256': file_sha(__file__),
    }
    write_json(protocol_file, specification)
    return specification


def read_protocol(folder, processed):
    folder = Path(folder)
    spec = load_json(folder/'protocol.json')
    for key, filename in (('catalog_sha256', 'catalog.json'),
                          ('validation_sha256', 'validation_manifest.csv'),
                          ('test_sha256', 'test_manifest.csv')):
        if file_sha(folder/filename) != spec[key]:
            raise RuntimeError(f'Manifest hash mismatch: {filename}')
    catalog = load_json(folder/'catalog.json')
    validate_catalog(processed, catalog)
    return spec, read_csv(folder/'validation_manifest.csv'), read_csv(folder/'test_manifest.csv')


def candidates():
    base = Config()
    return [
        (f'EGI_{number:02d}', replace(base, residual_scales=tuple(scales),
          zero_residual_prior=zero, free_motion_prior=free))
        for number, (scales, zero, free) in enumerate(product(
            ((0.0, 0.08, 0.20), (0.0, 0.12, 0.30)), (0.82, 0.92), (0.45, 0.70)))
    ]


def quantile(values, weights, fraction):
    order = np.argsort(values)
    v, w = values[order], weights[order]
    cum = np.cumsum(w)
    return float(v[min(int(np.searchsorted(cum, fraction, side='left')), len(v)-1)])


def score_particles(predictions, weights, truth, es_pairs, seed):
    if predictions.shape[:3] != truth.shape or weights.shape != (truth.shape[1], predictions.shape[-1]):
        raise ValueError('Prediction shape/weights do not match withheld future trajectories')
    if not np.isfinite(predictions).all() or not np.isfinite(weights).all():
        raise ValueError('Non-finite predictions or weights')
    rng = np.random.default_rng(seed)
    mean = np.einsum('tncs,ns->tnc', predictions, weights)
    dist = np.linalg.norm(predictions-truth[..., None], axis=2)
    e_dist = np.einsum('tns,ns->tn', dist, weights)
    e_sq = np.einsum('tns,ns->tn', dist**2, weights)
    mean_distance = np.linalg.norm(mean-truth, axis=2)
    summary = {
        'n': int(truth.shape[1]),
        'ade_sum': float(e_dist.mean(axis=0).sum()),
        'mean_ade_sum': float(mean_distance.mean(axis=0).sum()),
        'mean_fde5_sum': float(mean_distance[-1].sum()),
        'es_avg_sum': 0.0,
        'ese5_sum': float(e_sq[-1].sum()),
        'qde20_5_sum': 0.0,
        'coverage90_lon5_sum': 0.0,
        'coverage90_lat5_sum': 0.0,
        'width90_lon5_sum': 0.0,
        'width90_lat5_sum': 0.0,
        'horizon': [{'expected_distance_sum': 0., 'expected_squared_sum': 0.,
                     'energy_score_sum': 0., 'qde20_sum': 0.} for _ in HORIZONS],
    }
    for agent in range(truth.shape[1]):
        w = weights[agent]
        for index, t in enumerate(HORIZONS):
            pt = predictions[t, agent].T
            dd = dist[t, agent]
            if es_pairs == 0:
                pairs = np.linalg.norm(pt[:, None]-pt[None, :], axis=-1)
                pair_term = float(np.einsum('i,j,ij->', w, w, pairs))
            else:
                a = rng.choice(len(w), size=es_pairs, p=w)
                b = rng.choice(len(w), size=es_pairs, p=w)
                pair_term = float(np.linalg.norm(pt[a]-pt[b], axis=-1).mean())
            energy = float(w@dd-0.5*pair_term)
            qde = quantile(dd, w, 0.2)
            horizon = summary['horizon'][index]
            horizon['expected_distance_sum'] += float(w@dd)
            horizon['expected_squared_sum'] += float(w@(dd**2))
            horizon['energy_score_sum'] += energy
            horizon['qde20_sum'] += qde
            summary['es_avg_sum'] += energy/len(HORIZONS)
            if t == FUTURE-1:
                summary['qde20_5_sum'] += qde
                for axis, prefix in ((0, 'lat'), (1, 'lon')):
                    lo = quantile(predictions[t, agent, axis], w, 0.05)
                    hi = quantile(predictions[t, agent, axis], w, 0.95)
                    summary[f'coverage90_{prefix}5_sum'] += float(lo <= truth[t, agent, axis] <= hi)
                    summary[f'width90_{prefix}5_sum'] += hi-lo
    return summary


def fold_summary(sums):
    n = sums['n']
    if not n:
        raise ValueError('No eligible evaluation targets')
    return {
        'target_window_exposures': int(n),
        'expected_ADE_all50_m': sums['ade_sum']/n,
        'mean_ADE_all50_m': sums['mean_ade_sum']/n,
        'mean_FDE_5s_m': sums['mean_fde5_sum']/n,
        'distributional_RMSE_5s_m': math.sqrt(sums['ese5_sum']/n),
        'QDE20_5s_m': sums['qde20_5_sum']/n,
        'energy_score_avg_1to5_m': sums['es_avg_sum']/n,
        'coverage90_lon_5s': sums['coverage90_lon5_sum']/n,
        'coverage90_lat_5s': sums['coverage90_lat5_sum']/n,
        'width90_lon_5s_m': sums['width90_lon5_sum']/n,
        'width90_lat_5s_m': sums['width90_lat5_sum']/n,
    }


def blank_sums():
    return {key: (0 if key == 'n' else 0.) for key in (
        'n', 'ade_sum', 'mean_ade_sum', 'mean_fde5_sum', 'es_avg_sum',
        'ese5_sum', 'qde20_5_sum', 'coverage90_lon5_sum',
        'coverage90_lat5_sum', 'width90_lon5_sum', 'width90_lat5_sum')}


def add_sums(acc, entry):
    for key in acc:
        acc[key] += entry[key]
    return acc


def select_parameters(processed, out, fold='A', max_val=500, stride=20,
                      selection_seed=33, tuning_seed=117, n_samples=100,
                      es_pairs=128, ade_weight=0.5):
    out = Path(out)
    if n_samples < 1 or es_pairs < 0 or ade_weight < 0:
        raise ValueError('Invalid tuning parameters')
    if (out/'calibration.json').exists():
        raise FileExistsError(f'Calibration already frozen: {out}')
    if not (out/'protocol.json').exists():
        create_protocol(processed, out, fold, max_val, stride, selection_seed)
    spec, validation, _ = read_protocol(out, processed)
    if (spec.get('model_sha256') != file_sha(Path(__file__).with_name('model.py')) or
            spec.get('evaluation_sha256') != file_sha(__file__)):
        raise RuntimeError('Source code changed after protocol creation')
    if any(spec[key] != value for key, value in (
            ('fold', fold), ('max_val', max_val), ('stride', stride),
            ('manifest_seed', selection_seed))):
        raise RuntimeError('Tuning parameters differ from frozen protocol')
    all_scenes = list(iter_scenes(processed, validation))
    if not all_scenes:
        raise ValueError('Empty validation scenes')
    results = []
    progress_path = out/'tuning_progress.json'
    if progress_path.exists():
        state = load_json(progress_path)
        if state['protocol_sha256'] != file_sha(out/'protocol.json') or state['tuning_seed'] != tuning_seed or state['n_samples'] != n_samples or state['es_pairs'] != es_pairs or state['ade_weight'] != ade_weight:
            raise RuntimeError('Existing tuning progress belongs to different settings')
        results = state['results']
    for name, cfg in candidates():
        if any(r['candidate'] == name for r in results):
            continue
        predictor = EGIARKV2(cfg)
        totals = blank_sums()
        for item, history, truth, edges, _ in all_scenes:
            sample_seed = stable_seed(tuning_seed, item['scene_key'], 'prediction')
            predictions, weights, _ = predictor.predict_all(history, edges, n_samples=n_samples,
                                                          n_steps=FUTURE, seed=sample_seed,
                                                          return_diagnostics=False)
            scored = score_particles(predictions, weights, truth, es_pairs,
                                     stable_seed(tuning_seed, item['scene_key'], 'scoring'))
            add_sums(totals, scored)
        estimate = fold_summary(totals)
        results.append({
            'candidate': name,
            'energy_score_m': estimate['energy_score_avg_1to5_m'],
            'expected_ADE_all50_m': estimate['expected_ADE_all50_m'],
            'selection_value_m': estimate['energy_score_avg_1to5_m'] + ade_weight*estimate['expected_ADE_all50_m'],
            'target_exposures': estimate['target_window_exposures'],
        })
        write_json(progress_path, {'protocol_sha256': file_sha(out/'protocol.json'),
                  'tuning_seed': tuning_seed, 'n_samples': n_samples,
                  'es_pairs': es_pairs, 'ade_weight': ade_weight, 'results': results})
    winner = min(results, key=lambda entry: (entry['selection_value_m'], entry['candidate']))
    config = dict(candidates())[winner['candidate']]
    config.save(out/'selected_config.json')
    write_csv(out/'validation_scores.csv', results,
              ['candidate', 'energy_score_m', 'expected_ADE_all50_m', 'selection_value_m', 'target_exposures'])
    calibration = {
        'fold': fold, 'selected_candidate': winner['candidate'],
        'config': asdict(config), 'selection_objective': f'ES_1to5 + {ade_weight} * expected_ADE_all50',
        'ade_weight': ade_weight,
        'n_samples': n_samples, 'es_pairs': es_pairs,
        'manifest_seed': selection_seed, 'tuning_seed': tuning_seed,
        'stride': stride, 'max_val': max_val,
        'protocol_sha256': file_sha(out/'protocol.json'),
        'model_sha256': file_sha(Path(__file__).with_name('model.py')),
        'evaluation_sha256': file_sha(__file__),
        'results': results,
        'validation_only': True,
    }
    write_json(out/'calibration.json', calibration)
    return winner


def _connect(path):
    db = sqlite3.connect(path)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=NORMAL')
    db.execute('CREATE TABLE IF NOT EXISTS scenes (scene_key TEXT PRIMARY KEY, recording TEXT NOT NULL, filename TEXT NOT NULL, frame INTEGER NOT NULL, n INTEGER NOT NULL, runtime_s REAL NOT NULL, data TEXT NOT NULL)')
    return db


def _aggregate_database(db, out, expected_scenes):
    aggregate = blank_sums()
    horizon = [{'expected_distance_sum': 0., 'expected_squared_sum': 0.,
                'energy_score_sum': 0., 'qde20_sum': 0.} for _ in HORIZONS]
    by_record = defaultdict(blank_sums)
    num_scenes = 0
    total_runtime = 0.
    for recording, runtime, payload in db.execute('SELECT recording, runtime_s, data FROM scenes'):
        data = json.loads(payload)
        add_sums(aggregate, data)
        add_sums(by_record[recording], data)
        for current, values in zip(horizon, data['horizon']):
            for key in current:
                current[key] += values[key]
        num_scenes += 1
        total_runtime += runtime
    if not num_scenes:
        return None
    summary = fold_summary(aggregate)
    summary.update({'scenes_finished': num_scenes, 'scenes_in_manifest': expected_scenes,
                    'complete': num_scenes == expected_scenes,
                    'total_predict_runtime_s': total_runtime,
                    'mean_predict_runtime_ms_per_scene': total_runtime/num_scenes*1000})
    write_json(out/'summary.json', summary)
    write_csv(out/'summary.csv', [summary], list(summary))
    rows = []
    for name, scores in sorted(by_record.items()):
        row = {'recording': name, **fold_summary(scores)}
        rows.append(row)
    write_csv(out/'by_recording.csv', rows, list(rows[0]))
    time_rows = []
    for t, data in zip(HORIZONS, horizon):
        n = aggregate['n']
        time_rows.append({'horizon_s': (t+1)*0.1,
                          'expected_distance_m': data['expected_distance_sum']/n,
                          'distributional_RMSE_m': math.sqrt(data['expected_squared_sum']/n),
                          'energy_score_m': data['energy_score_sum']/n,
                          'QDE20_m': data['qde20_sum']/n})
    write_csv(out/'by_horizon.csv', time_rows, list(time_rows[0]))
    return summary


def evaluate_parameters(processed, calibration, out, seed=1, n_samples=None,
                        es_pairs=None, limit=0):
    processed = Path(processed)
    calibration_path = Path(calibration)
    calibration_data = load_json(calibration_path)
    protocol_dir = calibration_path.parent
    spec, _, test = read_protocol(protocol_dir, processed)
    if (calibration_data['protocol_sha256'] != file_sha(protocol_dir/'protocol.json') or
            calibration_data.get('model_sha256') != file_sha(Path(__file__).with_name('model.py')) or
            calibration_data.get('evaluation_sha256') != file_sha(__file__)):
        raise RuntimeError('Calibration does not match frozen experiment protocol')
    if (spec['fold'] != calibration_data['fold'] or spec['model_version'] != VERSION or
            spec.get('model_sha256') != file_sha(Path(__file__).with_name('model.py')) or
            spec.get('evaluation_sha256') != file_sha(__file__)):
        raise RuntimeError('Incompatible calibration and model version')
    samples = calibration_data['n_samples'] if n_samples is None else n_samples
    pairs = calibration_data['es_pairs'] if es_pairs is None else es_pairs
    if samples < 1 or pairs < 0 or limit < 0:
        raise ValueError('Invalid inference settings')
    if limit:
        test = test[:limit]
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    run_spec = {
        'fold': spec['fold'], 'protocol_sha256': calibration_data['protocol_sha256'],
        'calibration_sha256': file_sha(calibration_path), 'seed': seed,
        'n_samples': samples, 'es_pairs': pairs, 'limit': limit,
        'expected_scenes': len(test), 'model_version': VERSION,
    }
    run_path = out/'run_spec.json'
    if run_path.exists():
        if load_json(run_path) != run_spec:
            raise RuntimeError('Cannot mix experimental settings in an existing result directory')
    else:
        write_json(run_path, run_spec)
    db = _connect(out/'metrics.sqlite')
    model = EGIARKV2(Config.from_dict(calibration_data['config']))
    try:
        for item, obs, future, edges, _ in iter_scenes(processed, test):
            seen = db.execute('SELECT 1 FROM scenes WHERE scene_key=?', (item['scene_key'],)).fetchone()
            if seen:
                continue
            started = perf_counter()
            prediction, weight, _ = model.predict_all(
                obs, edges, n_samples=samples, n_steps=FUTURE,
                seed=stable_seed(seed, item['scene_key'], 'test_prediction'),
                return_diagnostics=False)
            spent = perf_counter()-started
            scores = score_particles(prediction, weight, future, pairs,
                                     stable_seed(seed, item['scene_key'], 'test_scoring'))
            db.execute('INSERT INTO scenes(scene_key, recording, filename, frame, n, runtime_s, data) VALUES (?,?,?,?,?,?,?)',
                       (item['scene_key'], item['recording'], item['file'], int(item['frame']),
                        int(scores['n']), float(spent), json.dumps(scores)))
            db.commit()
        return _aggregate_database(db, out, len(test))
    finally:
        db.close()
