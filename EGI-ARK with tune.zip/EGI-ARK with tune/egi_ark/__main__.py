from .model import _self_test, Config
import argparse
import json


def main():
    parser = argparse.ArgumentParser(description="EGI-ARK package utilities")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--write-default-config", metavar="PATH")
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(_self_test(), indent=2))
    elif args.write_default_config:
        Config().save(args.write_default_config)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
