


import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd
from egi_ark.highd import convert_recording, load_processed_scene


class TestHighD(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.raw = self.root/"raw"
        self.out = self.root/"processed"
        self.raw.mkdir()
        raw_frames = np.arange(125)
        tt = raw_frames/25.
        one = pd.DataFrame({
            "frame": raw_frames, "id": 1,
            "x": 150-20*tt, "y": 1.5+0*tt, "height": 0.8,
        })
        two = pd.DataFrame({
            "frame": raw_frames, "id": 2,
            "x": 5+22*tt, "y": 4.0+0*tt, "height": 0.8,
        })
        pd.concat([one, two]).to_csv(self.raw/"01_tracks.csv", index=False)
        pd.DataFrame({"id": [1, 2], "drivingDirection": [1, 2]}).to_csv(
            self.raw/"01_tracksMeta.csv", index=False)
        pd.DataFrame({"locationId": [1], "frameRate": [25],
                      "upperLaneMarkings": ["0;3.8;7.6"],
                      "lowerLaneMarkings": ["0;3.8;7.6"]}).to_csv(
            self.raw/"01_recordingMeta.csv", index=False)

    def test_converted_samples_and_direction(self):
        paths = convert_recording(self.raw, self.out, "01")
        self.assertEqual(len(paths), 4)
        up = pd.read_csv(self.out/"01_tracks1.csv")
        down = pd.read_csv(self.out/"01_tracks2.csv")
        np.testing.assert_array_equal(up.frame_id.to_numpy(), np.arange(50))
        self.assertEqual(up.agent_id.nunique(), 1)
        self.assertEqual(down.agent_id.nunique(), 1)
        np.testing.assert_allclose(up.x.values, 1.9)
        np.testing.assert_allclose(up.y.values, -(150-20*up.frame_id.to_numpy()/10), atol=1e-8)
        np.testing.assert_allclose(down.y.values, 5+22*down.frame_id.to_numpy()/10, atol=1e-8)
        obs, ids, lane_edges, meta, start = load_processed_scene(self.out/"01_tracks1.csv", 0)
        self.assertEqual(obs.shape, (30, 1, 2))
        self.assertEqual(ids, [1])
        self.assertEqual(start, 0)
        self.assertEqual(meta["driving_direction"], 1)
        self.assertTrue(np.all(np.diff(lane_edges[:, 0]) > 0))
        with self.assertRaises(FileExistsError):
            convert_recording(self.raw, self.out, "01")

    def test_raw_time_gap_not_interpolated(self):
        data = pd.read_csv(self.raw/"01_tracks.csv")
        data = data[~((data.id == 1) & (data.frame.isin([50, 51, 52, 53, 54, 55])))]
        data.to_csv(self.raw/"01_tracks.csv", index=False)
        convert_recording(self.raw, self.out, 1)
        up = pd.read_csv(self.out/"01_tracks1.csv")
        f = set(up.frame_id)
        self.assertNotIn(21, f)
        self.assertNotIn(22, f)

        self.assertTrue(max(f) > 40)

    def test_future_is_not_input(self):
        convert_recording(self.raw, self.out, "01")
        path = self.out/"01_tracks1.csv"
        orig, ids, _, _, _ = load_processed_scene(path, 0)
        df = pd.read_csv(path)
        df.loc[df.frame_id >= 30, "y"] += 9999
        df.to_csv(path, index=False)
        new, ids2, _, _, _ = load_processed_scene(path, 0)
        np.testing.assert_array_equal(orig, new)
        self.assertEqual(ids, ids2)


if __name__ == "__main__":
    unittest.main()
