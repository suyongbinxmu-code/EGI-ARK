import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from egi_ark.highd import convert_recording
from egi_ark.evaluation import (build_manifests, candidates, evaluate_parameters,
                                 read_protocol, score_particles, select_parameters)


class TestEvaluation(unittest.TestCase):
    def test_score_exact_sample(self):
        truth = np.zeros((50, 1, 2), dtype=float)
        predictions = np.ones((50, 1, 2, 3), dtype=float)
        weights = np.ones((1, 3))/3
        score = score_particles(predictions, weights, truth, 0, 13)
        self.assertAlmostEqual(score['ade_sum'], np.sqrt(2))
        self.assertAlmostEqual(score['ese5_sum'], 2.)
        self.assertAlmostEqual(score['es_avg_sum'], np.sqrt(2))
        self.assertAlmostEqual(score['qde20_5_sum'], np.sqrt(2))

    def test_folds_tuning_evaluation_and_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            raw, processed = root/'raw', root/'processed'
            raw.mkdir()
            processed.mkdir()
            t = np.arange(475)/25.
            for recording, location in (('01', 1), ('07', 4)):
                vehicle_rows, metas = [], []
                for direction in (1, 2):
                    for index in range(3):
                        agent = direction*100+index
                        signed_speed = (-1 if direction == 1 else 1)*20.
                        velocity = signed_speed*(t + 0.001*t*t)
                        vehicle_rows.append(pd.DataFrame({
                            'frame': np.arange(t.size), 'id': agent,
                            'x': 180 + index*12 + velocity,
                            'y': [1.5, 5.3, 1.5][index] + 0*t,
                            'height': 0.8,
                        }))
                        metas.append({'id': agent, 'drivingDirection': direction})
                pd.concat(vehicle_rows).to_csv(raw/f'{recording}_tracks.csv', index=False)
                pd.DataFrame(metas).to_csv(raw/f'{recording}_tracksMeta.csv', index=False)
                pd.DataFrame([{'locationId': location, 'frameRate': 25,
                              'upperLaneMarkings': '0;3.8;7.6',
                              'lowerLaneMarkings': '0;3.8;7.6'}]).to_csv(raw/f'{recording}_recordingMeta.csv', index=False)
                convert_recording(raw, processed, recording)
            cat, validation, test = build_manifests(processed, 'A', 2, 20, 33)
            self.assertEqual({x['recording'] for x in validation}, {'highd_01'})
            self.assertEqual({x['recording'] for x in test}, {'highd_07'})
            self.assertEqual(len(candidates()), 8)
            tunedir = root/'tune_A'
            selection = select_parameters(processed, tunedir, fold='A', max_val=2,
                                           stride=20, n_samples=2, es_pairs=8)
            self.assertIn(selection['candidate'], {name for name, _ in candidates()})
            spec, val, test = read_protocol(tunedir, processed)
            self.assertEqual(len(val), 2)
            self.assertGreater(len(test), 0)
            results = root/'eval_A'
            first = evaluate_parameters(processed, tunedir/'calibration.json',
                                        results, seed=1, n_samples=2, es_pairs=8, limit=2)
            second = evaluate_parameters(processed, tunedir/'calibration.json',
                                         results, seed=1, n_samples=2, es_pairs=8, limit=2)
            self.assertEqual(first, second)
            self.assertEqual(first['scenes_finished'], 2)
            self.assertEqual(first['scenes_in_manifest'], 2)
            self.assertTrue(first['complete'])
            self.assertGreater(first['target_window_exposures'], 0)
            self.assertGreater(first['distributional_RMSE_5s_m'], 0)
            with self.assertRaises(RuntimeError):
                evaluate_parameters(processed, tunedir/'calibration.json', results,
                                    seed=2, n_samples=2, es_pairs=8, limit=2)
            self.assertTrue((results/'by_recording.csv').exists())
            self.assertTrue((results/'by_horizon.csv').exists())
            self.assertTrue((tunedir/'selected_config.json').exists())
            self.assertTrue((tunedir/'validation_scores.csv').exists())


if __name__ == '__main__':
    unittest.main()
