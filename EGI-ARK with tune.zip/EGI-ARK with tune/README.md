# EGI-ARK

EGI-ARK is a probabilistic highway vehicle trajectory predictor. This repository contains its standalone model, highD preprocessing, validation-only parameter selection, and test evaluation.
## Install

Python 3.10+:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[highd]"
```

## Data

Obtain highD directly from [the dataset provider](https://levelxdata.com/highd-dataset/) under its access terms. Put each authorized recording's `XX_tracks.csv`, `XX_tracksMeta.csv`, and `XX_recordingMeta.csv` in `data/highd/raw/`. No highD data are included in this repository.

```bash
python -m scripts.preprocess_highd --raw-dir data/highd/raw --out-dir data/highd/processed
```

The converter creates 10 Hz, direction-specific trajectory files. No gaps are interpolated across a missing raw frame.

## Predict

```bash
python -m scripts.predict_highd --processed data/highd/processed/01_tracks1.csv --config configs/highd_fold_A.json --n-samples 100 --seed 33 --out-dir outputs/example
```

Each prediction uses 30 observed frames (3 s) to generate 50 future frames (5 s). `--n-samples 100` generates 300 equally weighted particles. Coordinates are stored as `[lateral, longitudinal]` in metres. The included `highd_fold_A.json` and `highd_fold_B.json` are frozen configurations from the earlier cross-location experiment; `configs/default.json` is a general inference example.

## Validate and evaluate EGI-ARK

Fold A: locations 1–3 for parameter selection, locations 4–6 for testing. Fold B swaps the locations. Each fold uses at most 500 validation origins; `stride=20` selects one test origin every 2 seconds. All eligible test origins are scored, with no test-label access during parameter selection.

```bash
python -m scripts.tune_highd --processed data/highd/processed --fold A --max-val 500 --stride 20 --out outputs/tune_A
python -m scripts.evaluate_highd --processed data/highd/processed --calibration outputs/tune_A/calibration.json --out outputs/eval_A
python -m scripts.tune_highd --processed data/highd/processed --fold B --max-val 500 --stride 20 --out outputs/tune_B
python -m scripts.evaluate_highd --processed data/highd/processed --calibration outputs/tune_B/calibration.json --out outputs/eval_B
```

The eight parameter candidates are ranked by `ES(1–5 s) + 0.5 × E-ADE(50 frames)`. Evaluation writes `summary.csv`, `by_horizon.csv`, `by_recording.csv`, and a resumable `metrics.sqlite`. E-ADE is the expected particle-to-truth distance; RMSE uses expected squared particle distance; ES is a marginal two-dimensional energy score, not a whole-trajectory joint score. To test a small subset, add `--limit 10 --out outputs/eval_A_small`. Repeat the same evaluation command to resume an interrupted run.

## Test

```bash
python -m egi_ark --self-test
python -m unittest discover -s tests
```
